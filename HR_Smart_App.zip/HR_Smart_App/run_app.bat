@echo off
chcp 65001 >nul
cd /d "%~dp0"
pip install -r requirements.txt
streamlit run app.py
pause
