# -*- coding: utf-8 -*-
"""
تطبيق «نظام التوظيف الذكي» — واجهة رسومية للنظام الخبير الضبابي
التشغيل:   streamlit run app.py
يحتاج الملف hr_fuzzy_system.py في نفس المجلد.
"""
import io
import os
import sqlite3

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import streamlit as st

import hr_fuzzy_system as hr

st.set_page_config(page_title="نظام التوظيف الذكي", page_icon="🧠", layout="wide")

# ---------- واجهة عربية من اليمين لليسار ----------
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700&display=swap');
html, body, [class*="css"], .stMarkdown, .stText, label, input, textarea, button, p, h1, h2, h3, h4
  { font-family: 'Tajawal', sans-serif !important; }
.main .block-container, section[data-testid="stSidebar"] { direction: rtl; text-align: right; }
.stTabs [data-baseweb="tab-list"] { direction: rtl; }
.decision { padding: 18px 22px; border-radius: 14px; font-size: 1.35rem; font-weight: 700; margin: 6px 0 14px; }
.hire { background:#E3F5E8; color:#1B6B34; border-right:6px solid #2E9E50; }
.short { background:#FFF4D6; color:#7A5A00; border-right:6px solid #E0A800; }
.reject { background:#FDE4E4; color:#9B1C1C; border-right:6px solid #D64545; }
.reason { background: rgba(127,127,127,.08); padding:10px 14px; border-radius:10px; margin:6px 0; }
</style>
""", unsafe_allow_html=True)

DB_PATH = "hr_results.db"


def decision_class(d):
    return "hire" if d.startswith("توصية") else ("short" if d.startswith("قائمة") else "reject")


def gauge(score, cfg):
    fig = go.Figure(go.Indicator(
        mode="gauge+number", value=score, number={"suffix": "%"},
        gauge={
            "axis": {"range": [0, 100]},
            "bar": {"color": "#1F4E78"},
            "steps": [
                {"range": [0, cfg["shortlist_threshold"]], "color": "#FDE4E4"},
                {"range": [cfg["shortlist_threshold"], cfg["hire_threshold"]], "color": "#FFF4D6"},
                {"range": [cfg["hire_threshold"], 100], "color": "#E3F5E8"},
            ],
        }))
    fig.update_layout(height=260, margin=dict(t=20, b=10, l=30, r=30))
    return fig


def mf_chart(var, value, title):
    fig = go.Figure()
    for t in var.terms:
        fig.add_trace(go.Scatter(x=var.universe, y=var[t].mf, name=hr.TERMS_AR.get(t, t),
                                 mode="lines", line=dict(width=3)))
    if value is not None:
        fig.add_vline(x=value, line_dash="dash", line_color="black")
    fig.update_layout(title=title, height=230, margin=dict(t=40, b=20, l=10, r=10),
                      legend=dict(orientation="h", y=-0.25), yaxis=dict(range=[0, 1.05]))
    return fig


def save_history(df):
    hr.save_to_sql(df, DB_PATH)


def load_history():
    if not os.path.exists(DB_PATH):
        return pd.DataFrame()
    with sqlite3.connect(DB_PATH) as con:
        try:
            return pd.read_sql("SELECT * FROM evaluations", con)
        except Exception:
            return pd.DataFrame()


# ---------- الشريط الجانبي: إعدادات الوظيفة ----------
with st.sidebar:
    st.header("⚙️ إعدادات الوظيفة")
    job = st.text_input("المسمى الوظيفي", hr.JOB_CONFIG["job_title"])
    budget = st.number_input("الميزانية الشهرية (ريال)", 1000, 200000,
                             hr.JOB_CONFIG["salary_budget"], step=500)
    st.subheader("حدود القرار")
    hire_t = st.slider("درجة التوصية بالتوظيف (من)", 40, 95, hr.JOB_CONFIG["hire_threshold"])
    short_t = st.slider("درجة القائمة المختصرة (من)", 10, hire_t - 1,
                        min(hr.JOB_CONFIG["shortlist_threshold"], hire_t - 1))
    st.subheader("الحد الأدنى الإلزامي")
    min_int = st.slider("أقل درجة مقابلة مقبولة", 0, 10, hr.JOB_CONFIG["minimums"]["interview"])
    min_skill = st.slider("أقل درجة مهارة مقبولة", 0, 10, hr.JOB_CONFIG["minimums"]["skill"])
    st.caption("🔒 العدالة: الاسم والجنس والعمر والجنسية لا تدخل في حساب الدرجة.")

CFG = dict(hr.JOB_CONFIG, job_title=job, salary_budget=budget,
           hire_threshold=hire_t, shortlist_threshold=short_t,
           minimums={"interview": min_int, "skill": min_skill})

st.title("🧠 نظام التوظيف الذكي")
st.caption(f"نظام خبير بالمنطق الضبابي لقرارات توظيف أكثر عدالة — الوظيفة: **{job}**")

tab1, tab2, tab3, tab4 = st.tabs(["👤 تقييم مرشح", "📂 تقييم ملف مرشحين",
                                  "📊 سجل التقييمات", "💡 كيف يعمل النظام"])

# ---------- 1) تقييم مرشح واحد ----------
with tab1:
    left, right = st.columns([1, 1.3], gap="large")
    with left:
        name = st.text_input("اسم المرشح (للعرض فقط)", "")
        exp_v = st.slider("سنوات الخبرة", 0.0, 10.0, 4.0, 0.5)
        skill_v = st.slider("المهارة التقنية (0-10)", 0.0, 10.0, 7.0, 0.5)
        int_v = st.slider("أداء المقابلة (0-10)", 0.0, 10.0, 7.0, 0.5)
        use_sal = st.checkbox("إضافة الراتب المتوقع", True)
        sal_v = st.number_input("الراتب المتوقع (ريال)", 0, 500000, int(budget), step=500,
                                disabled=not use_sal)
    res = hr.evaluate(exp_v, skill_v, int_v, sal_v if use_sal else None, CFG)
    with right:
        st.plotly_chart(gauge(res["score"], CFG), width="stretch")
        st.markdown(f'<div class="decision {decision_class(res["decision"])}">'
                    f'{res["decision"]}</div>', unsafe_allow_html=True)
        st.markdown("**ملف المرشح:** " + res["profile"])
        st.markdown("**لماذا هذا القرار؟**")
        for r in res["reasons"].split(" ؛ "):
            st.markdown(f'<div class="reason">{r}</div>', unsafe_allow_html=True)
        if st.button("💾 حفظ في السجل", type="primary"):
            row = pd.DataFrame([{
                "evaluated_at": pd.Timestamp.now().strftime("%Y-%m-%d %H:%M"),
                "job_title": job, "candidate_id": None, "name": name or "بدون اسم",
                "experience": exp_v, "skill": skill_v, "interview": int_v,
                "expected_salary": sal_v if use_sal else None,
                "salary_ratio": res["salary_ratio"], "score": res["score"],
                "decision": res["decision"], "reasons": res["reasons"]}])
            save_history(row)
            st.success("تم الحفظ في قاعدة البيانات ✔")

# ---------- 2) تقييم ملف ----------
with tab2:
    st.markdown("ارفعي ملف Excel أو CSV فيه الأعمدة: "
                "`experience` و`skill` و`interview`، واختيارياً `name` و`expected_salary` و`candidate_id`.")
    tpl = io.BytesIO()
    pd.DataFrame({"candidate_id": [101, 102, 103], "name": ["مرشح أ", "مرشح ب", "مرشح ج"],
                  "experience": [3, 7, 1], "skill": [8, 6, 4], "interview": [7, 8, 3],
                  "expected_salary": [11000, 15500, 9000]}).to_excel(tpl, index=False)
    st.download_button("⬇️ تحميل نموذج فارغ", tpl.getvalue(), "candidates_template.xlsx")

    up = st.file_uploader("ملف المرشحين", type=["xlsx", "csv"])
    if up is not None:
        try:
            df = pd.read_csv(up) if up.name.lower().endswith(".csv") else pd.read_excel(up)
            out = hr.evaluate_dataframe(df, CFG)
        except Exception as e:
            st.error(f"تعذّر قراءة الملف: {e}")
            st.stop()

        c1, c2, c3, c4 = st.columns(4)
        c1.metric("عدد المرشحين", len(out))
        c2.metric("توصية بالتوظيف", int(out["decision"].str.startswith("توصية").sum()))
        c3.metric("قائمة مختصرة", int(out["decision"].str.startswith("قائمة").sum()))
        c4.metric("رفض", int(out["decision"].str.startswith("رفض").sum()))

        label = out["name"] if "name" in out.columns else out["candidate_id"].astype(str)
        colors = out["decision"].map(lambda d: {"hire": "#2E9E50", "short": "#E0A800",
                                                "reject": "#D64545"}[decision_class(d)])
        fig = go.Figure(go.Bar(x=out["score"], y=label, orientation="h",
                               marker_color=colors, text=out["score"].astype(str) + "%",
                               textposition="outside"))
        fig.update_layout(height=max(250, 40 * len(out)), xaxis=dict(range=[0, 105]),
                          yaxis=dict(autorange="reversed"), margin=dict(t=10, l=10, r=10))
        st.plotly_chart(fig, width="stretch")

        show = {"rank": "الترتيب", "name": "الاسم", "experience": "الخبرة",
                "skill": "المهارة", "interview": "المقابلة",
                "expected_salary": "الراتب المتوقع", "score": "الدرجة",
                "decision": "القرار", "reasons": "السبب"}
        cols = [c for c in show if c in out.columns]
        st.dataframe(out[cols].rename(columns=show), width="stretch", hide_index=True)

        rep = io.BytesIO()
        hr.save_excel_report(out, rep, CFG)
        b1, b2 = st.columns(2)
        b1.download_button("⬇️ تحميل تقرير Excel", rep.getvalue(), "hr_report.xlsx",
                           type="primary", width="stretch")
        if b2.button("💾 حفظ النتائج في السجل", width="stretch"):
            save_history(out)
            st.success(f"تم حفظ {len(out)} مرشح في قاعدة البيانات ✔")

# ---------- 3) السجل ----------
with tab3:
    hist = load_history()
    if hist.empty:
        st.info("لا توجد تقييمات محفوظة بعد. احفظي نتيجة من التبويبين الأول أو الثاني.")
    else:
        jobs = ["الكل"] + sorted(hist["job_title"].dropna().unique().tolist())
        sel = st.selectbox("الوظيفة", jobs)
        h = hist if sel == "الكل" else hist[hist["job_title"] == sel]
        c1, c2, c3 = st.columns(3)
        c1.metric("إجمالي التقييمات", len(h))
        c2.metric("متوسط الدرجة", f"{h['score'].mean():.1f}%")
        c3.metric("نسبة التوصية بالتوظيف",
                  f"{100 * h['decision'].str.startswith('توصية').mean():.0f}%")
        counts = h["decision"].map(decision_class).value_counts()
        names = {"hire": "توصية بالتوظيف", "short": "قائمة مختصرة", "reject": "رفض"}
        fig = go.Figure(go.Pie(labels=[names[k] for k in counts.index], values=counts.values,
                               hole=.55, marker_colors=[{"hire": "#2E9E50", "short": "#E0A800",
                                                         "reject": "#D64545"}[k] for k in counts.index]))
        fig.update_layout(height=300, margin=dict(t=10, b=10))
        st.plotly_chart(fig, width="stretch")
        st.dataframe(h.sort_values("evaluated_at", ascending=False),
                     width="stretch", hide_index=True)
        st.download_button("⬇️ تصدير السجل (CSV لـ Power BI)",
                           h.to_csv(index=False).encode("utf-8-sig"), "hr_history.csv")

# ---------- 4) كيف يعمل ----------
with tab4:
    st.markdown("يحوّل النظام كل معيار إلى **درجات انتماء** لفئات لغوية (مثل: متوسطة 80%)، "
                "ثم يطبّق قواعد الخبراء، ويجمع النتائج بطريقة **مركز الثقل (Centroid)** "
                "ليخرج بدرجة قبول من 0 إلى 100. الخط المنقط يمثّل قيم المرشح الحالي من التبويب الأول.")
    a, b = st.columns(2)
    a.plotly_chart(mf_chart(hr.experience, exp_v, "سنوات الخبرة"), width="stretch")
    b.plotly_chart(mf_chart(hr.skill, skill_v, "المهارة التقنية"), width="stretch")
    a.plotly_chart(mf_chart(hr.interview, int_v, "أداء المقابلة"), width="stretch")
    b.plotly_chart(mf_chart(hr.salary, res["salary_ratio"], "نسبة الراتب للميزانية"),
                   width="stretch")
    st.plotly_chart(mf_chart(hr.acceptance, res["score"], "درجة القبول"), width="stretch")

    st.subheader("قاعدة القواعد")
    rules = []
    for i, r in enumerate(hr.BASE_RULES + hr.SALARY_RULES, 1):
        cond = " و ".join(f"{hr.CRITERIA_AR[v]} = {hr.TERMS_AR[t]}" for v, t in r["if"])
        rules.append({"#": i, "إذا": cond, "فإن القبول": hr.TERMS_AR[r["then"]], "المعنى": r["text"]})
    st.dataframe(pd.DataFrame(rules), width="stretch", hide_index=True)
