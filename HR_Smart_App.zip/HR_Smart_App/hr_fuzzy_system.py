# -*- coding: utf-8 -*-
"""
نظام خبير ذكي لقرارات توظيف أكثر عدالة (Fuzzy Expert Hiring System)
=====================================================================
نسخة مطوّرة من المشروع: تعتمد على المنطق الضبابي (scikit-fuzzy) وتضيف:
  1) معيار جديد: ملاءمة الراتب المتوقع لميزانية الوظيفة (اختياري لكل مرشح).
  2) إعدادات خاصة بكل وظيفة يغيّرها قسم الموارد البشرية (الميزانية، حدود القرار، الحد الأدنى).
  3) قرار واضح (توظيف / قائمة مختصرة / رفض) + تفسير مكتوب لسبب القرار.
  4) تقييم دفعة كاملة من ملف Excel أو CSV وترتيب المرشحين.
  5) حفظ النتائج في قاعدة بيانات SQL (SQLite) وتقرير Excel جاهز لـ Power BI.
  6) العدالة: النظام لا يستخدم الاسم أو الجنس أو العمر أو الجنسية في الحساب إطلاقاً.

طرق التشغيل:
  python hr_fuzzy_system.py                    -> إدخال مرشح يدوياً (تفاعلي)
  python hr_fuzzy_system.py --demo             -> تجربة المرشحين الأربعة من العرض التقديمي
  python hr_fuzzy_system.py candidates.xlsx    -> تقييم ملف كامل (xlsx أو csv)
  python hr_fuzzy_system.py --template         -> إنشاء ملف نموذج لتعبئة بيانات المرشحين
  python hr_fuzzy_system.py --plots            -> رسم دوال الانتماء (للعرض التقديمي)

المكتبات: pip install scikit-fuzzy numpy pandas openpyxl matplotlib networkx scipy
"""

import sys
import sqlite3
from datetime import datetime

import numpy as np
import pandas as pd
import skfuzzy as fuzz
from skfuzzy import control as ctrl


# =====================================================================
# 1) إعدادات الوظيفة — هذا الجزء يعدّله قسم الموارد البشرية
# =====================================================================
JOB_CONFIG = {
    "job_title": "مطوّر برمجيات",
    "salary_budget": 12000,        # الميزانية الشهرية للوظيفة (ريال)
    "hire_threshold": 65,          # الدرجة من 65 فأعلى  -> توصية بالتوظيف
    "shortlist_threshold": 45,     # من 45 إلى أقل من 65 -> قائمة مختصرة / مقابلة ثانية
    # الحد الأدنى الإلزامي (Knock-out): إن لم يحققه المرشح لا يُوصى به مهما كانت درجته
    "minimums": {
        "interview": 3,
        "skill": 3,
    },
    "db_path": "hr_results.db",
    "report_path": "hr_report.xlsx",
}

# أسماء المعايير بالعربي (للعرض والتفسير)
CRITERIA_AR = {
    "experience": "سنوات الخبرة",
    "skill": "المهارة التقنية",
    "interview": "أداء المقابلة",
    "salary": "ملاءمة الراتب",
}

TERMS_AR = {
    "low": "منخفضة", "medium": "متوسطة", "high": "عالية",
    "weak": "ضعيفة", "strong": "قوية",
    "poor": "ضعيف", "good": "جيد", "excellent": "ممتاز",
    "within": "ضمن الميزانية", "slightly_over": "أعلى قليلاً من الميزانية",
    "far_over": "أعلى بكثير من الميزانية",
}


# =====================================================================
# 2) تعريف المتغيرات الضبابية ودوال الانتماء (Membership Functions)
# =====================================================================
experience = ctrl.Antecedent(np.arange(0, 10.01, 0.1), "experience")
skill = ctrl.Antecedent(np.arange(0, 10.01, 0.1), "skill")
interview = ctrl.Antecedent(np.arange(0, 10.01, 0.1), "interview")
# الراتب يُحوَّل إلى نسبة: الراتب المتوقع ÷ الميزانية (1.0 = مطابق للميزانية)
salary = ctrl.Antecedent(np.round(np.arange(0.4, 1.601, 0.01), 2), "salary")
acceptance = ctrl.Consequent(np.arange(0, 100.01, 0.5), "acceptance")

# دوال مثلثية (trimf) كما في العرض، مع تضييق الفئة "المتوسطة" (2-8) لتمييز أوضح بين المرشحين
experience["low"] = fuzz.trimf(experience.universe, [0, 0, 5])
experience["medium"] = fuzz.trimf(experience.universe, [2, 5, 8])
experience["high"] = fuzz.trimf(experience.universe, [5, 10, 10])

skill["weak"] = fuzz.trimf(skill.universe, [0, 0, 5])
skill["medium"] = fuzz.trimf(skill.universe, [2, 5, 8])
skill["strong"] = fuzz.trimf(skill.universe, [5, 10, 10])

interview["poor"] = fuzz.trimf(interview.universe, [0, 0, 5])
interview["good"] = fuzz.trimf(interview.universe, [2, 5, 8])
interview["excellent"] = fuzz.trimf(interview.universe, [5, 10, 10])

salary["within"] = fuzz.trapmf(salary.universe, [0.4, 0.4, 1.0, 1.1])
salary["slightly_over"] = fuzz.trimf(salary.universe, [1.0, 1.15, 1.3])
salary["far_over"] = fuzz.trapmf(salary.universe, [1.2, 1.35, 1.6, 1.6])

acceptance["low"] = fuzz.trapmf(acceptance.universe, [0, 0, 15, 40])
acceptance["medium"] = fuzz.trimf(acceptance.universe, [30, 50, 70])
acceptance["high"] = fuzz.trapmf(acceptance.universe, [60, 85, 100, 100])

VARS = {"experience": experience, "skill": skill,
        "interview": interview, "salary": salary}


# =====================================================================
# 3) قاعدة القواعد (Rule Base)
#    القواعد 1-5 هي قواعد المشروع الأصلية، و6-10 تكمّل التغطية،
#    و11-13 خاصة بمعيار الراتب الجديد.
#    كل قاعدة: شروط (AND) + نتيجة + نص عربي للتفسير.
# =====================================================================
BASE_RULES = [
    # --- القواعد الأصلية ---
    {"if": [("experience", "high"), ("skill", "strong"), ("interview", "excellent")],
     "then": "high", "text": "خبرة عالية + مهارة قوية + مقابلة ممتازة"},
    {"if": [("experience", "medium"), ("skill", "medium"), ("interview", "good")],
     "then": "medium", "text": "خبرة ومهارة متوسطة مع مقابلة جيدة"},
    {"if": [("interview", "poor")],
     "then": "low", "text": "أداء المقابلة ضعيف"},
    {"if": [("experience", "low"), ("skill", "strong")],
     "then": "medium", "text": "المهارة القوية تعوّض قلة الخبرة"},
    {"if": [("skill", "weak")],
     "then": "low", "text": "المهارة التقنية ضعيفة"},
    # --- قواعد تكميلية (تضمن أن كل حالة لها قاعدة تنطبق عليها) ---
    {"if": [("skill", "strong"), ("interview", "excellent")],
     "then": "high", "text": "مهارة قوية مع مقابلة ممتازة"},
    {"if": [("skill", "strong"), ("interview", "good")],
     "then": "high", "text": "مهارة قوية مع مقابلة جيدة"},
    {"if": [("experience", "high"), ("skill", "medium"), ("interview", "good")],
     "then": "medium", "text": "خبرة عالية لكن المهارة متوسطة"},
    {"if": [("skill", "medium"), ("interview", "good")],
     "then": "medium", "text": "مهارة متوسطة مع مقابلة جيدة"},
    {"if": [("experience", "low"), ("skill", "medium")],
     "then": "low", "text": "خبرة قليلة ومهارة متوسطة"},
    {"if": [("skill", "medium"), ("interview", "excellent")],
     "then": "medium", "text": "مقابلة ممتازة مع مهارة متوسطة"},
]

SALARY_RULES = [
    {"if": [("salary", "within"), ("skill", "strong")],
     "then": "high", "text": "مرشح قوي وراتبه ضمن الميزانية"},
    {"if": [("salary", "slightly_over")],
     "then": "medium", "text": "الراتب المتوقع أعلى قليلاً من الميزانية (قابل للتفاوض)"},
    {"if": [("salary", "far_over")],
     "then": "low", "text": "الراتب المتوقع أعلى بكثير من الميزانية"},
]


def _build_system(rules):
    ctrl_rules = []
    for r in rules:
        cond = None
        for var, term in r["if"]:
            c = VARS[var][term]
            cond = c if cond is None else (cond & c)
        ctrl_rules.append(ctrl.Rule(cond, acceptance[r["then"]]))
    return ctrl.ControlSystem(ctrl_rules)


# نظامان: بدون راتب (المشروع الأصلي) ومع الراتب (المعيار الجديد)
SYSTEM_BASIC = _build_system(BASE_RULES)
SYSTEM_SALARY = _build_system(BASE_RULES + SALARY_RULES)


# =====================================================================
# 4) التقييم والتفسير
# =====================================================================
def _memberships(var_name, value):
    var = VARS[var_name]
    return {t: float(fuzz.interp_membership(var.universe, var[t].mf, value))
            for t in var.terms}


def _clip(v, lo, hi):
    return float(min(max(v, lo), hi))


def evaluate(exp_years, skill_score, interview_score, expected_salary=None,
             config=JOB_CONFIG):
    """يقيّم مرشحاً واحداً ويعيد الدرجة والقرار والتفسير."""
    inputs = {
        "experience": _clip(exp_years, 0, 10),   # أكثر من 10 سنوات تُعامل كـ 10
        "skill": _clip(skill_score, 0, 10),
        "interview": _clip(interview_score, 0, 10),
    }
    use_salary = expected_salary is not None and not pd.isna(expected_salary) \
        and config.get("salary_budget")
    if use_salary:
        ratio = float(expected_salary) / float(config["salary_budget"])
        inputs["salary"] = _clip(ratio, 0.5, 1.5)
        system, rules = SYSTEM_SALARY, BASE_RULES + SALARY_RULES
    else:
        system, rules = SYSTEM_BASIC, BASE_RULES

    sim = ctrl.ControlSystemSimulation(system)
    for k, v in inputs.items():
        sim.input[k] = v
    sim.compute()
    score = round(float(sim.output["acceptance"]), 1)

    # --- القرار ---
    failed = [CRITERIA_AR[k] for k, m in config.get("minimums", {}).items()
              if k in inputs and inputs[k] < m]
    if failed:
        decision = "رفض (لم يحقق الحد الأدنى)"
    elif score >= config["hire_threshold"]:
        decision = "توصية بالتوظيف"
    elif score >= config["shortlist_threshold"]:
        decision = "قائمة مختصرة / مقابلة ثانية"
    else:
        decision = "رفض"

    # --- التفسير: درجة انتماء كل معيار + أقوى القواعد التي أثّرت ---
    mems = {k: _memberships(k, v) for k, v in inputs.items()}
    profile = []
    for k, m in mems.items():
        best = max(m, key=m.get)
        profile.append(f"{CRITERIA_AR[k]}: {TERMS_AR[best]} ({m[best]:.0%})")

    fired = []
    for r in rules:
        strength = min(mems[v][t] for v, t in r["if"])
        if strength > 0.05:
            fired.append((strength, r))
    fired.sort(key=lambda x: x[0], reverse=True)
    reasons = [f"{r['text']} ← قبول {TERMS_AR[r['then']]} (قوة {s:.0%})"
               for s, r in fired[:3]]
    if failed:
        reasons.insert(0, "لم يحقق الحد الأدنى في: " + "، ".join(failed))

    return {
        "score": score,
        "decision": decision,
        "profile": " | ".join(profile),
        "reasons": " ؛ ".join(reasons),
        "salary_ratio": round(inputs["salary"], 2) if use_salary else None,
    }


# =====================================================================
# 5) تقييم دفعة من ملف + الحفظ في SQL + تقرير Excel
# =====================================================================
REQUIRED_COLS = ["experience", "skill", "interview"]
# الأعمدة الشخصية لا تدخل في الحساب (العدالة) — تُستخدم للعرض فقط
PERSONAL_COLS = ["name", "gender", "age", "nationality"]


def evaluate_dataframe(df, config=JOB_CONFIG):
    missing = [c for c in REQUIRED_COLS if c not in df.columns]
    if missing:
        raise ValueError(f"أعمدة ناقصة في الملف: {missing}")
    if "candidate_id" not in df.columns:
        df.insert(0, "candidate_id", range(1, len(df) + 1))

    rows = []
    for _, row in df.iterrows():
        res = evaluate(row["experience"], row["skill"], row["interview"],
                       row.get("expected_salary"), config)
        rows.append(res)
    out = pd.concat([df.reset_index(drop=True), pd.DataFrame(rows)], axis=1)
    out = out.sort_values("score", ascending=False).reset_index(drop=True)
    out.insert(0, "rank", range(1, len(out) + 1))
    out["job_title"] = config["job_title"]
    out["evaluated_at"] = datetime.now().strftime("%Y-%m-%d %H:%M")
    return out


def save_to_sql(results, db_path):
    """يحفظ النتائج في جدول evaluations (يمكن ربطه بـ Power BI)."""
    keep = ["evaluated_at", "job_title", "candidate_id", "name", "experience",
            "skill", "interview", "expected_salary", "salary_ratio",
            "score", "decision", "reasons"]
    cols = [c for c in keep if c in results.columns]
    with sqlite3.connect(db_path) as con:
        results[cols].to_sql("evaluations", con, if_exists="append", index=False)


def save_excel_report(results, path, config=JOB_CONFIG):
    from openpyxl.styles import Font, PatternFill, Alignment
    from openpyxl.utils import get_column_letter

    rename = {
        "rank": "الترتيب", "candidate_id": "رقم المرشح", "name": "الاسم",
        "experience": "الخبرة (سنوات)", "skill": "المهارة (0-10)",
        "interview": "المقابلة (0-10)", "expected_salary": "الراتب المتوقع",
        "salary_ratio": "نسبة الراتب للميزانية", "score": "درجة القبول",
        "decision": "القرار", "profile": "ملف المرشح", "reasons": "سبب القرار",
    }
    show = [c for c in rename if c in results.columns]
    table = results[show].rename(columns=rename)

    summary = pd.DataFrame({
        "البند": ["الوظيفة", "الميزانية", "عدد المرشحين", "توصية بالتوظيف",
                  "قائمة مختصرة", "رفض", "متوسط الدرجة", "أعلى درجة"],
        "القيمة": [config["job_title"], config["salary_budget"], len(results),
                   int((results["decision"] == "توصية بالتوظيف").sum()),
                   int(results["decision"].str.startswith("قائمة").sum()),
                   int(results["decision"].str.startswith("رفض").sum()),
                   round(results["score"].mean(), 1), results["score"].max()],
    })

    with pd.ExcelWriter(path, engine="openpyxl") as xw:
        table.to_excel(xw, sheet_name="النتائج", index=False)
        summary.to_excel(xw, sheet_name="الملخص", index=False)
        colors = {"توصية": "C6EFCE", "قائمة": "FFEB9C", "رفض": "FFC7CE"}
        for ws in xw.book.worksheets:
            ws.sheet_view.rightToLeft = True
            for cell in ws[1]:
                cell.font = Font(bold=True, color="FFFFFF")
                cell.fill = PatternFill("solid", fgColor="1F4E78")
                cell.alignment = Alignment(horizontal="center", wrap_text=True)
            for i, col in enumerate(ws.columns, 1):
                width = max(len(str(c.value or "")) for c in col)
                ws.column_dimensions[get_column_letter(i)].width = min(max(12, width + 2), 60)
        ws = xw.book["النتائج"]
        dcol = list(table.columns).index("القرار") + 1
        for r in range(2, ws.max_row + 1):
            val = str(ws.cell(r, dcol).value)
            for key, color in colors.items():
                if val.startswith(key):
                    for c in range(1, ws.max_column + 1):
                        ws.cell(r, c).fill = PatternFill("solid", fgColor=color)
        ws.freeze_panes = "A2"


def run_file(path, config=JOB_CONFIG):
    df = pd.read_csv(path) if path.lower().endswith(".csv") else pd.read_excel(path)
    results = evaluate_dataframe(df, config)
    save_to_sql(results, config["db_path"])
    save_excel_report(results, config["report_path"], config)
    print_table(results)
    print(f"\n✔ التقرير: {config['report_path']}   ✔ قاعدة البيانات: {config['db_path']}")
    return results


# =====================================================================
# 6) أدوات مساعدة: طباعة، نموذج، رسوم، وضع تفاعلي
# =====================================================================
def print_table(results):
    print(f"\nنتائج التقييم — وظيفة: {JOB_CONFIG['job_title']}")
    print("-" * 70)
    for _, r in results.iterrows():
        name = r.get("name", r["candidate_id"])
        print(f"#{r['rank']}  {name}:  {r['score']}%  →  {r['decision']}")
        print(f"     {r['reasons']}")


def make_template(path="candidates_template.xlsx"):
    pd.DataFrame({
        "candidate_id": [101, 102, 103],
        "name": ["مرشح أ", "مرشح ب", "مرشح ج"],
        "experience": [3, 7, 1],
        "skill": [8, 6, 4],
        "interview": [7, 8, 3],
        "expected_salary": [11000, 15500, 9000],
    }).to_excel(path, index=False)
    print(f"✔ تم إنشاء النموذج: {path} — عبّئه ثم شغّل: python hr_fuzzy_system.py {path}")


def plot_memberships(path="membership_functions.png"):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, axes = plt.subplots(5, 1, figsize=(8, 14))
    for ax, var in zip(axes, [experience, skill, interview, salary, acceptance]):
        for t in var.terms:
            ax.plot(var.universe, var[t].mf, linewidth=2, label=t)
        ax.set_title(var.label)
        ax.legend(loc="upper right")
        ax.set_ylim(-0.05, 1.05)
    plt.tight_layout()
    plt.savefig(path, dpi=150)
    print(f"✔ تم حفظ الرسم: {path}")


def ask_number(prompt, optional=False):
    while True:
        s = input(prompt).strip()
        if optional and s == "":
            return None
        try:
            return float(s)
        except ValueError:
            print("  الرجاء إدخال رقم.")


def interactive():
    print(f"=== تقييم مرشح — وظيفة: {JOB_CONFIG['job_title']} "
          f"(الميزانية {JOB_CONFIG['salary_budget']}) ===")
    e = ask_number("سنوات الخبرة (0-10): ")
    s = ask_number("المهارة التقنية (0-10): ")
    i = ask_number("أداء المقابلة (0-10): ")
    sal = ask_number("الراتب المتوقع (اتركه فارغاً للتخطي): ", optional=True)
    r = evaluate(e, s, i, sal)
    print(f"\nدرجة القبول: {r['score']}%")
    print(f"القرار: {r['decision']}")
    print(f"ملف المرشح: {r['profile']}")
    print(f"السبب: {r['reasons']}")


DEMO = pd.DataFrame({  # المرشحون الأربعة من العرض التقديمي
    "candidate_id": [1, 2, 3, 4],
    "experience": [2, 6, 1, 4],
    "skill": [8, 7, 4, 7],
    "interview": [6, 8, 3, 6],
})


if __name__ == "__main__":
    args = sys.argv[1:]
    if not args:
        interactive()
    elif args[0] == "--demo":
        print_table(evaluate_dataframe(DEMO.copy()))
    elif args[0] == "--template":
        make_template()
    elif args[0] == "--plots":
        plot_memberships()
    else:
        run_file(args[0])
